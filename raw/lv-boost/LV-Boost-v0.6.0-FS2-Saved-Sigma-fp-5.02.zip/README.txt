LV Boost v0.6.0 — SIGMA fp firmware 5.02 development card

Fast Start 2; remembers the last +1/+2/+3 level and enabled/disabled state.
First use defaults to +2. Select OFF or another COLOR preset to keep LV Boost
inactive on the next boot. Normal shutdown saves the preference; do not pull
the battery while the camera is saving. Keep USB unplugged during boot.

Back up the card first. Copy AutoRun.txt, fpSup.BIN and FPSUPUI to its root.
Existing v0.5.1/v0.5.2 FS2 users need only replace fpSup.BIN; all other card
files are byte-identical. Safely eject before putting the card in the camera.
This is an alternative to RAW View, not a merge input.

Offline tests passed; v0.6.0 saved settings have not booted on camera.
Native settings persistence, repeated power cycles and capture isolation
still require hardware checks. This is a development build.

Persistent preference: CommonSave +0x210 (0xC307544C), separate from Fast.
Deleting card files does not erase it. Invalid/reset data uses first-use +2.
See raw/lv-boost/README.md in the PR for implementation and limits.
