LV BOOST — Live View Boost
v0.5.2 development build for SIGMA fp firmware 5.02

Renames the COLOR-menu icon to LV BOOST. Fast Start 2 and automatic +2
startup behavior are unchanged from the previous v0.5.1 card.

UPDATING
From v0.5.1, back up and replace only fpSup.BIN. AutoRun.txt and the five
FPSUPUI files are byte-identical. For a fresh installation, copy AutoRun.txt,
fpSup.BIN and FPSUPUI to the card root. Safely eject before use.

USE
LV Boost selects +2 after stable STILL live view begins. A manual color
selection overrides the pending default. Select +1/+2/+3 in the COLOR menu,
or a native color preset to disable it. Restarting defaults to +2 again.
The native full color title may still show OFF; the menu icon says LV BOOST.

VALIDATION
13 tests and exact-card emulation through all three loading paths passed.
The prior +3 build was confirmed to activate on STILL power-up; the +2
build was installed and read back. This renamed build has not been tested
on camera. Cold versus warm STILL boot, repeated power cycles, capture/JPEG
isolation and HDMI/EVF testing remain incomplete. The lifted display is not
an exposure reference. FS2 stores loader bytes in camera settings.
