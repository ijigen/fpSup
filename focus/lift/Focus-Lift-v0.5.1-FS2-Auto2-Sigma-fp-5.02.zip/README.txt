FOCUS LIFT v0.5.1 — Fast Start 2 / automatic +2
Development build for SIGMA fp firmware 5.02

The only camera-code change from v0.5.0 is the startup level: +2 instead of +3.
Fast Start 2 and the startup timing are unchanged. Manual color selection
still overrides the startup default. Every restart defaults to +2.

UPDATING FROM v0.5.0
Back up fpSup.BIN, replace it with this package's fpSup.BIN, and safely eject.
AutoRun.txt and FPSUPUI are byte-identical to v0.5.0; keep them in place.
For a fresh installation, all three (AutoRun.txt, fpSup.BIN and FPSUPUI)
belong at the card root. Do not combine with RAW Live View or another mod.

VALIDATION
The user confirmed automatic +3 and working STILL power-up on v0.5.0.
Whether that was a cold or warm start was not separately established.
The +2 build passed four startup tests and exact-package emulation through
ordinary, saved-bootstrap and warm-hook loading, with shutdown restoration.
Only one byte differs in fpSup.BIN: the startup variant immediate.
Physical +2 startup has not yet been confirmed.

The display title may still read OFF. The selected +2 and actual brightening
are the relevant checks. The lifted display is not an exposure reference.
Capture/JPEG/embedded-preview isolation and repeated power-cycle testing
remain incomplete. FS2 stores loader bytes in the camera's settings area.
